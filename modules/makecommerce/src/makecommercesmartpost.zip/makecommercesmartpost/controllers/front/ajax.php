<?php
require ( _PS_MODULE_DIR_ .'makecommerce/libs/makecommerce_carrier_ajax.php');


class makecommercesmartpostajaxModuleFrontController extends MakeCommerceAjaxController
{

}

?>